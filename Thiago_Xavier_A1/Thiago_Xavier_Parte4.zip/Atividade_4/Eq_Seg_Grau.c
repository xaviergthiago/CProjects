#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
	float delta (float a, float b, float c){
	float d;
	d=pow(b, 2)-4*a*c;
	return (d);
	}
	
	float raiz1 (float a, float b, float c) {
	float x1;
	x1=(-b+sqrt(delta(a, b, c)))/2*a;
	printf ("O valor da segunda raiz � %f ", x1);
	return (x1);
	}
	
	float raiz2 (float a, float b, float c) {
	float x2;
	x2=(-b-sqrt(delta(a, b, c)))/2*a;
	printf ("O valor da segunda raiz � %f ", x2);
	return (x2);
	}
		
int main(int argc, char *argv[]) {
	float a, b, c;
	printf ("Digite o valor de a ");
	scanf ("%f", &a);
	printf ("Digite o valor de b ");
	scanf ("%f", &b);
	printf ("Digite o valor de c ");
	scanf ("%f", &c);
	
	raiz1 (a, b, c);
	raiz2 (a, b, c);
	
	
	return 0;
}
