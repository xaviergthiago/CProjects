#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main()
{
    int vetor[10]={1, 3, 5, 7, 9, 11, 13, 15, 17, 19};
    int i;
    for (i=0; i<9; i++)
    printf("%d ", vetor[i]);

    return 0;
}

