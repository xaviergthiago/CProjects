#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float vetorx[3], vetory[3], vetorzs[3], vetorzd[3], vetorzp[3];
	int i;
	for (i=0; i<3; i++){
	printf ("Digite o %d valor de A ", i+1);
	scanf ("%f", &vetorx[i]);

	printf ("Digite o %d valor de B ", i+1);
	scanf ("%f", &vetory[i]);
	
	vetorzs[i]=vetorx[i]+vetory[i];
	vetorzd[i]=vetorx[i]-vetory[i];
	vetorzp[i]=vetorx[i]*vetory[i];
	}

	for (i=0; i<3; i++){
		printf ("\n%f", vetorx[i]);
		printf ("\n%f\n", vetory[i]);
	}
		
	for (i=0; i<3; i++){
		printf ("\nA soma das posi��es %d do vetor � %f ", i+1, vetorzs[i]);
		printf ("\nA diferen�a entre as posi��es %d dos vetores A e B � %f ", i+1, vetorzd[i]);
		printf ("\nO produto das posi��es %d dos vetores � %f \n", i+1, vetorzp[i]);
	}
	return 0;
}
