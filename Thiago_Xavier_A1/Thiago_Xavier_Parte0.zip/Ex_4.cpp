#include <stdio.h>
#include <stdlib.h>
int main(int argc, char** argv) {
	float n;
	printf ("Digite um n�mero: ");
	scanf ("%f", &n);
	printf ("\nO triplo desse n�mero � %f", 3*n);
	return 0;
	
}
