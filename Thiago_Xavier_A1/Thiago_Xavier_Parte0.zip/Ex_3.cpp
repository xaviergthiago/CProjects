#include <stdio.h>
#include <stdlib.h>
int main(int argc, char** argv) {
	int n, m;
	printf ("Digite o primeiro n�mero: ");
	scanf ("%d", &n);
	printf ("Digite o segundo n�mero: ");
	scanf ("%d", &m);
	printf ("\nA soma dos n�mero � %d", n+m);
	return 0;
	
}
