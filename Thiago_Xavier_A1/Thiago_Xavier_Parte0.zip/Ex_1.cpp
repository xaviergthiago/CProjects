#include <stdio.h>
#include <stdlib.h>
int main(int argc, char** argv) {
	float n;
	printf ("Digite um n�mero: ");
	scanf ("%f", &n);
	printf ("O n�mero � %f", n);
	return 0;
	
}
