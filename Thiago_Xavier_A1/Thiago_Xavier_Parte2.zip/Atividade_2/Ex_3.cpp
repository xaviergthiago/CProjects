#include <stdio.h>

int main()
{
  int i;
  
  for(i = 1; i <= 10; i++)
  {
    printf("\nO n�mero %d ao quadrado � %d ", i, i*i);
  }
  
  
  return(0);
}
